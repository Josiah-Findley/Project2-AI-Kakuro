# Othello
Instructions on how to run our Othello game in Eclipse.

1) All options for game are in Data Vars at top of Othello Main

2) Can play with any combo of players and AI's

3) Ai's use Alpha Beta Pruning with MiniMax

4) 4 different Heuristics for the AI's

5) Iterative Deepening with timeout is an option

6) Sorting moves before checking them is an option

7) Optimal endgame parity heuristic is also an option when depth equals number of moves left

8) The depths of both AI's can also be set, as well as the Min Depth for iterative Deepening




